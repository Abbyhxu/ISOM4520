# SimpleBacktestingEngine

This repo is designed as a tool for the ISOM4520 class. It is a backtesting engine/framework that can be used for the assignments and the term project.